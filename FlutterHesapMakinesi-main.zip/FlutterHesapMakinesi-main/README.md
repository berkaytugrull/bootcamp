# FlutterHesapMakinesi
 Flutter ile geliştirdiğim basit hesap makinesi uygulaması.

![image](https://user-images.githubusercontent.com/56456793/146962935-9627c8aa-edf6-44c2-9381-aece52e1b29c.png)
![image](https://user-images.githubusercontent.com/56456793/146963101-954042bd-e3cf-4ba4-b0d3-de817b98e465.png)
![image](https://user-images.githubusercontent.com/56456793/146963259-7951ce3b-911d-4344-9a5e-5c2800506978.png)
