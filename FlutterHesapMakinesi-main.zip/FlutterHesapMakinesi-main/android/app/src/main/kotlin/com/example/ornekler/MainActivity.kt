package com.example.ornekler

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
